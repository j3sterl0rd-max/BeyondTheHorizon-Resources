IRENOIR Resource Pack
Minecraft Java Edition 1.21.1
NeoForge 21.1.249 compatible

What it does:
- Renames selected vanilla iron-related blocks, items, and the Iron Golem with custom Irenoir jokes.
- Changes display text only.
- Does NOT change IDs, tags, recipes, mining behavior, drops, or registry entries.

Install:
1. Put Irenoir_1.21.1_final.zip into your .minecraft/resourcepacks folder.
2. Enable it in Options > Resource Packs.

Compatibility:
Because this only overrides vanilla language entries, all affected content keeps its normal
Minecraft registry IDs internally. Mods still see and use the normal vanilla blocks/items/entities.
